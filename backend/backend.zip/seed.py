from app import create_app, db
from app.models.stamp import Stamp

# Tworzenie aplikacji
app = create_app()

# Dodawanie przykładowych danych
with app.app_context():
    db.create_all()  # Tworzy tabele w bazie danych

    # Przykładowe dane
    stamps = [
        Stamp(
            name="Polish Eagle",
            description="Commemorative stamp featuring the Polish eagle.",
            price=10.50,
            year_issued=2021,
            country="Poland",
            quantity_available=100,
            image_url="https://example.com/polish_eagle.jpg"
        ),
        Stamp(
            name="US Flag",
            description="American flag stamp from 2020.",
            price=5.75,
            year_issued=2020,
            country="USA",
            quantity_available=200,
            image_url="https://example.com/us_flag.jpg"
        )
    ]

    # Dodaj znaczniki do bazy
    db.session.add_all(stamps)
    db.session.commit()

    print("Dane testowe zostały dodane do bazy.")
