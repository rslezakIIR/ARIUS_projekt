import { Link } from 'react-router-dom';
import { useStamps } from '../contexts/StampsContext';
import { StampCard } from '../components/StampCard';

const Home = () => {
  const { stamps, loading } = useStamps();
  const featuredStamps = Array.isArray(stamps) ? stamps.slice(0, 3) : []; // Display first 3 stamps as featured

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Sklep Filatelistyczny</h1>
        <p className="text-xl text-gray-600">
          Odkryj naszą wyjątkową kolekcję znaczków pocztowych
        </p>
      </div>

      <div className="bg-blue-600 text-white rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Witamy w naszym sklepie</h2>
        <p className="mb-6">Znajdź znaczki, których szukasz w naszej bogatej kolekcji</p>
        <Link
          to="/collection"
          className="bg-white text-blue-600 px-6 py-2 rounded-full font-semibold hover:bg-gray-100"
        >
          Zobacz kolekcję
        </Link>
      </div>

      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Wyróżnione znaczki</h2>
        {loading ? (
          <div className="text-center py-8">Ładowanie...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredStamps.map((stamp) => (
              <StampCard key={stamp.id} stamp={stamp} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;