import React, { useEffect, useState } from 'react';

const Collection = () => {
  const [stamps, setStamps] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/api/stamps')
      .then(response => {
        if (!response.ok) {
          console.error(`Server returned ${response.status}: ${response.statusText}`);
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log('Fetched data:', data);
        setStamps(data.stamps); // Adjust if the backend's response structure changes
      })
      .catch(error => console.error('Error fetching stamps:', error));
  }, []);
  

  return (
    <div className="collection">
      {stamps && stamps.length > 0 ? (
        stamps.map(stamp => (
          <div key={stamp.id} className="stamp">
            <h3>{stamp.name}</h3>
            <p>{stamp.description}</p>
          </div>
        ))
      ) : (
        <p>No stamps found</p>
      )}
    </div>
  );
};

export default Collection;
