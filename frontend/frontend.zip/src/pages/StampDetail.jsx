import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import Rating from '../components/Rating';
import '../styles/main.css';

const StampDetail = () => {
  const { id } = useParams();
  const { addToCart } = useCart();
  const [stamp, setStamp] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStamp = async () => {
      try {
        setLoading(true);
        const response = await fetch(`http://localhost:5000/api/stamps/${id}`);
        if (!response.ok) {
          throw new Error('Nie można pobrać danych znaczka');
        }
        const data = await response.json();
        setStamp(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchStamp();
  }, [id]);

  if (loading) return <div className="text-center py-8">Ładowanie...</div>;
  if (error) return <div className="text-center text-red-500 py-8">{error}</div>;
  if (!stamp) return <div className="text-center py-8">Nie znaleziono znaczka</div>;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="md:flex">
          <div className="md:w-1/2">
            <img
              src={stamp.imageUrl}
              alt={stamp.name}
              className="w-full h-96 object-contain p-4"
            />
          </div>
          <div className="md:w-1/2 p-8">
            <h1 className="text-3xl font-bold mb-4">{stamp.name}</h1>
            <p className="text-gray-600 mb-4">{stamp.description}</p>
            
            <div className="space-y-4 mb-6">
              <div>
                <h3 className="font-semibold">Szczegóły:</h3>
                <p>Wymiary: {stamp.dimensions}</p>
                <p>Stan: {stamp.condition}</p>
                <p>Rok wydania: {stamp.year}</p>
              </div>

              <div className="flex items-center space-x-2">
                <span className="font-semibold">Ocena:</span>
                <Rating initialRating={stamp.rating} readonly={true} />
              </div>
            </div>

            <div className="flex items-center justify-between mt-8">
              <span className="text-3xl font-bold">{stamp.price} zł</span>
              <button
                onClick={() => addToCart(stamp)}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
              >
                Dodaj do koszyka
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StampDetail;