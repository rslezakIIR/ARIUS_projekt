import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Navigation = () => {
  const { user, logout } = useAuth();

  return (
    <nav className="bg-blue-600 text-white shadow-lg">
      <div className="container mx-auto px-6 py-3">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-xl font-bold">
            Sklep Filatelistyczny
          </Link>
          <div className="flex items-center space-x-4">
            <Link to="/collection" className="hover:text-blue-200">
              Kolekcja
            </Link>
            {user ? (
              <>
                <Link to="/cart" className="hover:text-blue-200">
                  Koszyk
                </Link>
                <Link to="/profile" className="hover:text-blue-200">
                  Profil
                </Link>
                <button
                  onClick={logout}
                  className="hover:text-blue-200"
                >
                  Wyloguj
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="hover:text-blue-200">
                  Logowanie
                </Link>
                <Link to="/register" className="hover:text-blue-200">
                  Rejestracja
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;